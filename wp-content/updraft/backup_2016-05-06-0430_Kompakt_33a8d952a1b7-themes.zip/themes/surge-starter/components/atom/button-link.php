<?php 
  $var['class'] = $vars[0];
  $var['name'] = $vars[1];
  $var['link'] = $vars[2];
 ?>

<a class="<?php echo $var['class'] ?>" href="<?php echo $var['link'] ?>"><?php echo $var['name']; ?>
</a>