<a class="brand"  href="<?= esc_url(home_url('/')); ?>">
 <img height="40px" src="<?php echo $vars['logo'] ?>" alt="<?php bloginfo('name'); ?>">
	<!-- <i class="icon-Kompakt_LOGO"></i> -->
</a>