<section class="content-text text-center">
	<div class="wrapper">
			<h1></h1>
			<h2></h2>
			<p>Lorem ipsum dolor sit amet, <b>consectetur</b> adipisicing elit. Aliquid odit architecto recusandae! Ab, animi, ex. Aut accusantium assumenda tempore nam nobis, necessitatibus earum doloribus, at sint quo a. Perferendis, nobis?</p>
	</div>
</section>