<div class="social-contact">
	<ul>
		<li><i class="icon-telephone"></i>+61 (0)459 752 136 </li>
		<li><i class="icon-facebook"></i></li>
		<li><i class="icon-instagram"></i></li>
		<li><i class="icon-pinterest"></i></li>
	</ul>
</div>