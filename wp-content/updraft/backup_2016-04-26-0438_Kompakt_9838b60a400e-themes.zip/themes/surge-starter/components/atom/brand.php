<a class="brand" href="<?= esc_url(home_url('/')); ?>">
	<img src="<?php echo get_field('brand','option');?>" alt="<?php bloginfo('name'); ?>">
</a>