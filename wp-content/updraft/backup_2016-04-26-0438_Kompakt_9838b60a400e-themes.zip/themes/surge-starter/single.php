<?php get_template_part('components/content-single', get_post_type()); ?>
